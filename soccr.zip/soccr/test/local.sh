unshare -Urn sh -c 'ip link set up dev lo && make test'
